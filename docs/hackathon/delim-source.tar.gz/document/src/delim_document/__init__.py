"""Delim Document service."""
