"""Document domain models."""
