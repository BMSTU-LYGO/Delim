"""OCR providers."""
