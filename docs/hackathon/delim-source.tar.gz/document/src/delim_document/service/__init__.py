"""Document use cases."""
