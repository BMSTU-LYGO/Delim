"""Object storage adapters."""
