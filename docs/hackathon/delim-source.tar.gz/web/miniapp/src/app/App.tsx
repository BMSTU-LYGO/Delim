import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';

import { AppShell } from './AppShell';
import { GroupsPage } from '../features/groups/GroupsPage';
import { CreateGroupPage } from '../features/groups/CreateGroupPage';
import { GroupDashboardPage } from '../features/groups/GroupDashboardPage';
import { SessionLanding } from '../session/SessionLanding';
import { MembersPage } from '../features/groups/MembersPage';
import { CreateExpensePage } from '../features/expenses/CreateExpensePage';
import { ExpenseDetailsPage } from '../features/expenses/ExpenseDetailsPage';
import { EditExpensePage } from '../features/expenses/EditExpensePage';
import { ReceiptPage } from '../features/receipts/ReceiptPage';
import { BalanceRoute } from '../features/balance/BalanceRoute';
import { SettlementsPage } from '../features/settlements/SettlementsPage';

export function App() {
  return (
    <BrowserRouter>
      <SessionLanding />
      <Routes>
        <Route element={<AppShell />}>
          <Route index element={<GroupsPage />} />
          <Route path="groups/new" element={<CreateGroupPage />} />
          <Route path="groups/:groupId" element={<GroupDashboardPage />} />
          <Route
            path="groups/:groupId/expense/new"
            element={<CreateExpensePage />}
          />
          <Route path="expenses/:expenseId" element={<ExpenseDetailsPage />} />
          <Route
            path="expenses/:expenseId/edit"
            element={<EditExpensePage />}
          />
          <Route path="receipts/:receiptId" element={<ReceiptPage />} />
          <Route path="groups/:groupId/balance" element={<BalanceRoute />} />
          <Route
            path="groups/:groupId/members"
            element={<MembersPage />}
          />
          <Route
            path="groups/:groupId/settlements"
            element={<SettlementsPage />}
          />
        </Route>
        <Route path="*" element={<Navigate replace to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}
