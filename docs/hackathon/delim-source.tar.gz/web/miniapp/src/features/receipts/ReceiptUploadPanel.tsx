import { Button, Flex, Typography } from '@maxhub/max-ui';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { userErrorMessage } from '../../api';
import { FormMessage, useDirtyForm } from '../../components/form';
import { maxBridge } from '../../platform/maxBridge';
import { useSession } from '../../session/SessionProvider';
import { routes } from '../../app/routes';
import { parseFiscalQr, type FiscalQr } from './fiscalQr';
import { prepareReceiptImage, ReceiptImageError, supportedReceiptImageTypes } from './imageUpload';

const formatBytes = (bytes: number) =>
  new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 }).format(bytes / 1024 / 1024) + ' МБ';

interface ReceiptUploadPanelProps {
  groupId: number;
}

export function ReceiptUploadPanel({ groupId }: ReceiptUploadPanelProps) {
  const { client } = useSession();
  const navigate = useNavigate();
  const cameraRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const inFlight = useRef(false);
  const scanInFlight = useRef(false);
  const [file, setFile] = useState<File>();
  const [previewUrl, setPreviewUrl] = useState<string>();
  const [qrValue, setQRValue] = useState<string>();
  const [fiscalQr, setFiscalQr] = useState<FiscalQr>();
  const [loading, setLoading] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string>();
  const [feedback, setFeedback] = useState<string>();

  useDirtyForm(Boolean(file));

  useEffect(() => {
    if (!file) {
      setPreviewUrl(undefined);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const chooseFile = async (nextFile?: File) => {
    setError(undefined);
    setFeedback(undefined);
    if (!nextFile) return;
    if (!supportedReceiptImageTypes.has(nextFile.type)) {
      setError('Поддерживаются только JPEG, PNG и WebP');
      return;
    }
    setPreparing(true);
    try {
      setFile(await prepareReceiptImage(nextFile));
    } catch (cause) {
      setFile(undefined);
      setError(cause instanceof ReceiptImageError ? cause.message : 'Не удалось подготовить изображение');
    } finally {
      setPreparing(false);
    }
  };

  const scanQR = async () => {
    if (scanInFlight.current) return;
    scanInFlight.current = true;
    setScanning(true);
    setError(undefined);
    setFeedback(undefined);
    try {
      const result = await maxBridge.scanQRCode(false);
      if (result.status === 'success') {
        setQRValue(result.value);
        const parsed = parseFiscalQr(result.value);
        setFiscalQr(parsed);
        if (!parsed) {
          setFeedback("QR прочитан, но это не QR кассового чека");
          return;
        }
        setLoading(true);
        try {
          const created = await client.createReceiptFromQR(
            groupId,
            result.value,
          );
          navigate(routes.receipt(String(created.receipt.id)), {
            state: { groupId },
          });
        } catch (cause) {
          setError(userErrorMessage(cause, "Не удалось получить чек по QR"));
        } finally {
          setLoading(false);
        }
      } else if (result.status === 'cancelled') {
        setFeedback('Сканирование QR-кода отменено.');
      } else if (result.status === 'unsupported') {
        setError('Сканер QR недоступен в этой версии MAX. Используйте камеру или галерею.');
      } else if (result.status === 'permission_denied') {
        setError('Нет доступа к камере MAX. Разрешите доступ или выберите чек из галереи.');
      } else {
        setError('Не удалось открыть сканер MAX. Используйте камеру или галерею.');
      }
    } finally {
      scanInFlight.current = false;
      setScanning(false);
    }
  };

  const upload = async () => {
    if (!file || inFlight.current) return;
    inFlight.current = true;
    setLoading(true);
    setError(undefined);
    try {
      const result = await client.uploadReceipt(groupId, file);
      navigate(routes.receipt(String(result.receipt.id)), {
        state: { groupId },
      });
    } catch (cause) {
      setError(userErrorMessage(cause, 'Не удалось загрузить чек'));
    } finally {
      inFlight.current = false;
      setLoading(false);
    }
  };

  return (
    <section aria-labelledby="receipt-upload-title" className="dashboard-card receipt-upload" id="receipt-upload">
      <Flex direction="column" gap={12}>
        <Flex direction="column" gap={4}>
          <Typography.Headline asChild variant="small">
            <h3 id="receipt-upload-title">Сканировать чек</h3>
          </Typography.Headline>
          <Typography.Body color="secondary" variant="small">
            Сфотографируйте чек или выберите JPEG, PNG или WebP до 25 МБ — изображение сожмётся перед
            отправкой.
          </Typography.Body>
        </Flex>

        <input
          accept="image/jpeg,image/png,image/webp"
          aria-label="Сделать фото чека"
          capture="environment"
          className="visually-hidden"
          disabled={loading || scanning || preparing}
          onChange={(event) => {
            void chooseFile(event.target.files?.[0]);
            event.target.value = '';
          }}
          ref={cameraRef}
          type="file"
        />
        <input
          accept="image/jpeg,image/png,image/webp"
          aria-label="Выбрать изображение чека"
          className="visually-hidden"
          disabled={loading || scanning || preparing}
          onChange={(event) => {
            void chooseFile(event.target.files?.[0]);
            event.target.value = '';
          }}
          ref={fileRef}
          type="file"
        />

        {previewUrl && file ? (
          <div className="receipt-upload__preview">
            <img alt="Предпросмотр выбранного чека" src={previewUrl} />
            <Flex direction="column" gap={4}>
              <Typography.Body>{file.name}</Typography.Body>
              <Typography.Body color="secondary" variant="small">
                {formatBytes(file.size)}
              </Typography.Body>
            </Flex>
          </div>
        ) : null}

        <div className="receipt-upload__actions">
          <Button
            disabled={loading || scanning || preparing}
            onClick={() => cameraRef.current?.click()}
            size="small"
            type="button"
            variant="secondary"
          >
            Камера
          </Button>
          <Button
            disabled={loading || scanning || preparing}
            loading={scanning}
            onClick={() => void scanQR()}
            size="small"
            type="button"
          >
            QR в MAX
          </Button>
          <Button
            disabled={loading || scanning || preparing}
            onClick={() => fileRef.current?.click()}
            size="small"
            type="button"
            variant="secondary"
          >
            Из галереи
          </Button>
        </div>

        {fiscalQr ? (
          <Typography.Body className="receipt-upload__qr" color="tertiary" variant="small">
            QR распознан<br />
            {new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }).format(
              new Date(`${fiscalQr.date}T00:00:00`),
            )}
            , {fiscalQr.time}<br />
            {new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(
              fiscalQr.sum,
            )}{' '}
            ₽
          </Typography.Body>
        ) : qrValue ? (
          <Typography.Body className="receipt-upload__qr" color="tertiary" variant="small">
            QR: {qrValue}
          </Typography.Body>
        ) : null}
        <FormMessage>{error}</FormMessage>
        <FormMessage tone="success">{preparing ? 'Подготавливаем изображение…' : undefined}</FormMessage>
        <FormMessage tone="success">{feedback}</FormMessage>
        {file ? (
          <Button
            disabled={loading || scanning || preparing}
            loading={loading}
            onClick={() => void upload()}
            size="medium"
            stretched
          >
            Распознать чек
          </Button>
        ) : null}
      </Flex>
    </section>
  );
}
